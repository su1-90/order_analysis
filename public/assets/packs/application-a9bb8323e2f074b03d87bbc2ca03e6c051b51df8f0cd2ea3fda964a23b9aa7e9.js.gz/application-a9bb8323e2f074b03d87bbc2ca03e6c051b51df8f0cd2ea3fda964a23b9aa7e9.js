console.log('Hello, Webpack!');
